package com.example.calculo_imc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText campoPeso, campoAltura;
    private TextView campoResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        campoPeso = findViewById(R.id.editPeso);
        campoAltura = findViewById(R.id.editAltura);
        campoResultado = findViewById(R.id.editResultado);
    }

    public void calcular(View view) {
        String peso = campoPeso.getText().toString();
        String altura = campoAltura.getText().toString();

        Double campoPeso = Double.parseDouble(peso);
        Double campoAltura = Double.parseDouble(altura);

        double imc = campoPeso/(campoAltura*campoAltura);

        if(imc < 18.5) {
            campoResultado.setText("Magreza. Voce está abaixo do peso. Seu IMC é: " + imc );

        } else if (imc > 18.6) {
            campoResultado.setText("Normal. Voce está no peso ideal! Seu IMC é: " + imc);

        } else if (imc > 25.0) {
            campoResultado.setText("Sobrepeso. Seu IMC é: " + imc);

        } else if (imc > 30.0) {
            campoResultado.setText("Obesidade grau I. Seu IMC é: " + imc);

        } else if (imc > 35.0) {
            campoResultado.setText("Obesidade grau II. Seu IMC é: " + imc);

        } else if (imc > 40.0) {
            campoResultado.setText("Obesidade grau III. Seu IMC é: " + imc);
        }

       // campoResultado.setText("Seu IMC é de: " + imc);

    }

    public void limpar(View view) {
        campoPeso.setText(" ");
        campoAltura.setText(" ");
        campoResultado.setText(" ");
    }

}